from django.shortcuts import render
from django.db.models import Q  # Import Q object
from .models import Person

# relative import of forms
from .forms import RideForm

# Create your views here.


def index(request):

  context = {}

  # Initialize an empty queryset
  filtered_people = Person.objects.all()

  if "city_search" in request.GET and "state_search" in request.GET:
    city_search = request.GET["city_search"]
    state_search = request.GET["state_search"]

    # Apply filtering using Q objects and logical OR
    filtered_people = filtered_people.filter(
        Q(origination__icontains=city_search) |
        Q(destination_city__icontains=city_search),
        Q(destination_state__icontains=state_search) )

    # Assign filtered queryset to context
    context["people"] = filtered_people

  
  context["form"] = RideForm()

  return render(request, "index_view.html", context)
