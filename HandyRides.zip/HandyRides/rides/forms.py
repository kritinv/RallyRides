from django import forms


class RideForm(forms.Form):
  city_search = forms.CharField(label='City', max_length=64)
  state_search = forms.CharField(label='State', max_length=64)

