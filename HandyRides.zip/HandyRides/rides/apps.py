from django.apps import AppConfig


class RidesConfig(AppConfig):
    name = 'rides'
